#pragma once
#include "..\Common\ProcessList.h"

NODE_PROCESS* process1;
extern int num = 5;;