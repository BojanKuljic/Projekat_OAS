#pragma once

bool TestSync(int ServiceID);

bool TestAsync(int ServiceID);

bool TestHandler(int ServiceID, int ServiceType);